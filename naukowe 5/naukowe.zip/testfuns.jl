#Tomasz Janik

include("./MatModule.jl")
using .MatModule
using Test


function testGauss(matrixPath::String = "", vectorPath::String = "", outPath::String = "",
                     choose::Bool = false, genB::Bool = false)
    local matrix
    local vec
    local results


    if matrixPath == ""
        error("Can't open file with matrix")
    else
        matrix = readMatrix(matrixPath)
    end

    if !genB
        vec = readVector(vectorPath)

    else
        t = generateBVec(matrix[1], matrix[2], matrix[3])

        vec = (t, 0)
    end

    if choose
        results = solveGaussPivot(matrix[1], vec[1], matrix[2], matrix[3])
    else
        results = solveGauss(matrix[1], vec[1], matrix[2], matrix[3])
    end

    if outPath != ""
        writeRes(outPath, results, matrix[2], genB)
    end

    @testset "Test solutions" begin
        @test isapprox(results, ones(matrix[2]))
    end
end


function testLU(matrixPath::String = "", vectorPath::String = "", outPath::String = "",
                                choose::Bool = false, genB::Bool = false)
    local matrix
    local vec
    local results


    if matrixPath == ""
        error("Can't open file with matrix")
    else
        matrix = readMatrix(matrixPath)
    end

    if !genB
        vec = readVector(vectorPath)

    else
        t = generateBVec(matrix[1], matrix[2], matrix[3])

        vec = (t, 0)
    end

    if choose
        tmp = luDecompPivot(matrix[1], vec[1], matrix[2], matrix[3])
        results = solveLuDecompPivot(tmp[1], tmp[2], vec[1], matrix[2], matrix[3])
    else
        tmp = luDecomp(matrix[1], vec[1], matrix[2], matrix[3])
        results = solveLuDecomp(tmp[1], vec[1], matrix[2], matrix[3])
    end

    if outPath != ""
        writeRes(outPath, results, matrix[2], genB)
    end

    @testset "Test solutions" begin
        @test isapprox(results, ones(matrix[2]))
    end
end
